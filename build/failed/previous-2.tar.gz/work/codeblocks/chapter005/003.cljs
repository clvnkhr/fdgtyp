(def u (+ (* 'u↑0 d:dx) (* 'u↑1 d:dy) (* 'u↑2 d:dz)))

(def v (+ (* 'v↑0 d:dx) (* 'v↑1 d:dy) (* 'v↑2 d:dz)))

(def w (+ (* 'w↑0 d:dx) (* 'w↑1 d:dy) (* 'w↑2 d:dz)))

(simplify (((wedge dx dy dz) u v w) R3-rect-point))
;; => (+ (* u↑0 v↑1 w↑2)
;;       (* -1 u↑0 v↑2 w↑1)
;;       (* -1 u↑1 v↑0 w↑2)
;;       (* u↑1 v↑2 w↑0)
;;       (* u↑2 v↑0 w↑1)
;;       (* -1 u↑2 v↑1 w↑0))
