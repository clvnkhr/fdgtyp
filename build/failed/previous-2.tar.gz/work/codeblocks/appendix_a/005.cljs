(fn [& formal-parameters] body)
