(if predicate consequent alternative)
