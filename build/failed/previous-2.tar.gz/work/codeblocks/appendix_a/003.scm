(lambda (x) (* x x))
