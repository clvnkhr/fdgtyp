(lambda formal-parameters body)
